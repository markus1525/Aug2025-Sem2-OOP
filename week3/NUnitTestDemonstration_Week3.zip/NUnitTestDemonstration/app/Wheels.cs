using System.Runtime.CompilerServices;

namespace HelloWorld{
    public class Wheel{

        private int diameter;
        public string brand;

        public Wheel(int diameterInput, string brandInput){
            diameter = diameterInput;
            brand = brandInput;
        }

        //get and set methods (aka property)
    }
    
}
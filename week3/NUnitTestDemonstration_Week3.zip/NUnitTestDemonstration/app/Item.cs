namespace SwinAdventure
{
    public class Item
    {

        private List<string> _identifiers;
        private string description;

        private string _name;
    }
}
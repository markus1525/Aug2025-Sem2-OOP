public class TestInventory
{
    [SetUp]
    public void Setup()
    {
    }
}
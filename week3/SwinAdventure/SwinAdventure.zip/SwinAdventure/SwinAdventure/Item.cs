using System;
using System.Collections.Generic;

namespace SwinAdventure
{
    public class Item
    {
        //C
        private List<string> _identifiers;

        // Add private fields
        private string _name;
        private string _description;

        // Constructor for the Item.
        public Item(string[] idents, string name, string desc)
        {
            _identifiers = new List<string>(idents);
            _name = name;
            _description = desc;
        }

        public bool AreYou(string id)
        {
            return _identifiers.Contains(id.ToLower());
        }

        public void PrivilegeEscalation(string pin)
        {
            _identifiers[0] = "TUTE01";
        }

        public string FirstId
        {
            get { return _identifiers[0]; }
        }

        // A read-only property to get the item's name.
        public string Name
        {
            get { return _name; }
        }

        // A read-only property that formats a short description.
        public string ShortDescription
        {
            get { return "a " + _name + " (" + _identifiers[0] + ")"; }
        }

        // A read-only property to get the item's full description.
        public string LongDescription
        {
            get { return _description; }
        }

        //Verfication Task
        public List<string> IdList
        {
            get { return _identifiers; }
        }
    }
}
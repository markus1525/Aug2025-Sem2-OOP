using System;

namespace SwinAdventure
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Create and start the complete adventure game
            Game game = new Game();
            game.Start();
        }
    }
}